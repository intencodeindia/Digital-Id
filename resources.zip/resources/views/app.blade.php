@extends('layouts.app')

@section('content')
    @yield('content')
@endsection

